# codeofduty — Enterprise IDS Model Package

Run inference with:
```bash
python predict.py --input test.csv --output pred.csv
```

The input is a headerless CSV containing exactly 38 feature columns.
The output is `row_id,prediction,probability`, with 1-based sequential row IDs.
The cost-sensitive decision threshold is 0.02.

`model.joblib` is the serialized trained LightGBM model and should not be retrained
or modified before organizer verification.
