import argparse
import joblib
import numpy as np
import pandas as pd

FEATURE_NAMES = [
    "proto","state","dur","sbytes","dbytes","sloss","dloss","service",
    "Sload","Dload","Spkts","Dpkts","swin","dwin","stcpb","dtcpb",
    "smeansz","dmeansz","trans_depth","res_bdy_len","Sjit","Djit",
    "Sintpkt","Dintpkt","tcprtt","synack","ackdat","is_sm_ips_ports",
    "ct_flw_http_mthd","is_ftp_login","ct_ftp_cmd","ct_srv_src",
    "ct_srv_dst","ct_dst_ltm","ct_src_ltm","ct_src_dport_ltm",
    "ct_dst_sport_ltm","ct_dst_src_ltm"
]
CATEGORICAL_FEATURES = ["proto", "state", "service"]
THRESHOLD = 0.02

def preprocess(df, model):
    if df.shape[1] != len(FEATURE_NAMES):
        raise ValueError(
            f"Expected {len(FEATURE_NAMES)} feature columns, got {df.shape[1]}."
        )
    df = df.copy()
    df.columns = FEATURE_NAMES

    # Match training preprocessing.
    df["ct_ftp_cmd"] = df["ct_ftp_cmd"].replace(r"^\s*$", np.nan, regex=True)
    df["ct_ftp_cmd"] = pd.to_numeric(df["ct_ftp_cmd"], errors="coerce")

    # Reuse the exact categorical vocabularies stored by LightGBM.
    saved_categories = getattr(model.booster_, "pandas_categorical", None)
    if saved_categories is not None:
        for col, cats in zip(CATEGORICAL_FEATURES, saved_categories):
            df[col] = pd.Categorical(df[col], categories=cats)
    else:
        for col in CATEGORICAL_FEATURES:
            df[col] = df[col].astype("category")
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    model = joblib.load("model.joblib")
    df = pd.read_csv(args.input, header=None)
    X = preprocess(df, model)

    probabilities = model.predict_proba(X)[:, 1]
    predictions = (probabilities >= THRESHOLD).astype(int)

    out = pd.DataFrame({
        "row_id": np.arange(1, len(df) + 1),
        "prediction": predictions,
        "probability": probabilities
    })
    out.to_csv(args.output, index=False)

if __name__ == "__main__":
    main()
